package kr.co.soft.advisor;

public class AdvisorClass {

   public void beforeMethod() {
      System.out.println("beforeMethod 호풀");
      
   }
   
   public void afterMethod() {
	      System.out.println("afterMethod 호풀");
	      
	   }
}