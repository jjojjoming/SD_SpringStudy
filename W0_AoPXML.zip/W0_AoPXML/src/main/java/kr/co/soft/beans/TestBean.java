package kr.co.soft.beans;

public class TestBean {

   public void method1() {
      System.out.println("method1 호출");
   }
